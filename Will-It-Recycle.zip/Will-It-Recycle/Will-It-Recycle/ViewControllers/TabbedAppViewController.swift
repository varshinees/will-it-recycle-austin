//
//  ViewController.swift
//  Will-It-Recycle
//
//  Created by Varshinee - School on 3/11/21.
//

import UIKit
import Firebase

class TabbedAppViewController: UITabBarController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

//    @IBAction func signOut(_ sender: Any) {
//        do { try Auth.auth().signOut() }
//            catch { print("already logged out") }
//
//        performSegue(withIdentifier: "BackToStart", sender: nil)
//
//        let loginVC = LoginViewController()
//        present(loginVC, animated: false, completion: nil)

//            navigationController?.popToRootViewController(animated: true)
//    }
    
}

